<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">0.1.2</td>
			<td align="left">
				<ul>
					<li>Updated readme.</li>
					<li>Prevent ever reducing the maximum melee attack angle.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">0.1.1</td>
			<td align="left">
				<ul>
					<li>Adjust default attack angle config setting.</li>
					<li>Fixed bug that effectively doubled max allowed attack angle.</li>
					<li>Updated mod icon.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">0.1.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>
